// #ifndef SCHEDULER

// void scheduleRR(struct cpu *c, struct proc *proc);
// void scheduleFCFS(struct cpu *c, struct proc *proc);
// void schedulePBS(struct cpu *c, struct proc *proc);
// void scheduleLBS(struct cpu *c, struct proc *proc);
// int noTickets(struct proc *process);
// int settickets(int tickets);
// int do_rand(unsigned long *ctx);
// #endif